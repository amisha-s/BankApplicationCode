package com.fis.bankApplication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankApplication.exception.UserNotFound;
import com.fis.bankApplication.model.Transfer;
import com.fis.bankApplication.repository.TransferRepo;

@Service
public class TransferService {
	@Autowired
	TransferRepo transferRepo;
// method is used to add a log to the database
	public void addLog(Transfer transfer) {
		transferRepo.save(transfer);
	}
// method is used to retrieve a log by its account ID
	public Transfer showLog(int acctID) throws UserNotFound {
		Optional<Transfer> optional = transferRepo.findById(acctID);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new UserNotFound("Account Number is invalid...");
		}
		//return loggerRepo.findById(acctID).orElse(null);
	}
// method is used to delete a log by its account ID
	public void deleteLog(int acctID) {
		transferRepo.deleteById(acctID);
	}
}

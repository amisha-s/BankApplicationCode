package com.fis.bankApplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankApplication.model.Client;
import com.fis.bankApplication.repository.ClientRepo;

@Service
public class ClientService {
	@Autowired
	private ClientRepo clientRepo;
// this method is used to create the customer
	public void createCustomer(Client client) {
		clientRepo.save(client);
	}
// this method is used to get customer information by account ID
	public Client getCustomerInfo(int acctID) {
		return clientRepo.findById(acctID).orElse(null);
	}
// this method is used to delete the customer by account ID
	public void deleteCustomer(int acctID) {
		clientRepo.deleteById(acctID);
	}

}

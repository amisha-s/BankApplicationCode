package com.fis.bankApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * 
 * @author Ayush Srivastava
 *
 */

@SpringBootApplication
public class BankApplication {
	
// this invokes the 'run' method of 'springapplication' to launch the spring boot application
	public static void main(String[] args) {
		SpringApplication.run(BankApplication.class, args);
	}

}

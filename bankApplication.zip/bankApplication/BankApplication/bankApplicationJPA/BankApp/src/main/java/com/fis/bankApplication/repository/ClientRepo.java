package com.fis.bankApplication.repository;

import org.springframework.data.repository.CrudRepository;

import com.fis.bankApplication.model.Client;

public interface ClientRepo extends CrudRepository<Client, Integer> {

}

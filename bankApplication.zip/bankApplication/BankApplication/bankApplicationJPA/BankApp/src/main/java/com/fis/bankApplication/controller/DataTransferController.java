package com.fis.bankApplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankApplication.exception.UserNotFound;
import com.fis.bankApplication.model.Transfer;
import com.fis.bankApplication.service.TransferService;

@RestController
public class DataTransferController {
	@Autowired
	private TransferService transferService;

	// addLog method definition
	public void addLog(Transfer transfer) {
		// this method adds a log using the loggerservice
		transferService.addLog(transfer);
	}

	// showLog
	// this method is used to retrieve and return logs based on the account ID
	@GetMapping("/account/{acctID}/logs")
	public Transfer showLog(@PathVariable int acctID) throws UserNotFound {
		return transferService.showLog(acctID);
	}

	public void deleteLog(int acctID) {
		// this method is responsible for deleting logs using loggerservice
		transferService.deleteLog(acctID);
	}
}

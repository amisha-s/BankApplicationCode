package com.fis.bankApplication.repository;

import org.springframework.data.repository.CrudRepository;

import com.fis.bankApplication.model.Transfer;

public interface TransferRepo extends CrudRepository<Transfer, Integer> {

}

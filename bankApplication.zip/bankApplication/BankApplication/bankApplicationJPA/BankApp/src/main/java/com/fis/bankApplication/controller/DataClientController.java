package com.fis.bankApplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankApplication.exception.WrongResponse;
import com.fis.bankApplication.model.Client;
import com.fis.bankApplication.service.ClientService;

@RestController
public class DataClientController {
	@Autowired
	private ClientService clientService;
	@Autowired
	private DataAccountController dataAccountController;

	@PostMapping("/customer")
	public void createCustomer(@RequestBody Client client) {
		//call customer service to create the customer
		clientService.createCustomer(client);
		// call accountController to create an account for the customer with a 0 balance and active status
		dataAccountController.createAccount(client.getAcctID(), 0, "Active");
	}

	@GetMapping("/customer/{acctID}")
// Handling the exception with responseEntity using
		public ResponseEntity<?> getCustomerInfo(@PathVariable int acctID) {
	        Client user = clientService.getCustomerInfo(acctID);
	        if (user == null) {
	          WrongResponse wrongResponse = new WrongResponse();
	          wrongResponse.setMessage("Record not found");
	          return new ResponseEntity<>(wrongResponse, HttpStatus.NOT_FOUND);
	         }
	       return new ResponseEntity<>(user, HttpStatus.OK); 
	    }    
	

	@DeleteMapping("/customer/{acctID}")
	public void deleteCustomer(@PathVariable int acctID) {
		// delete the account details of the customer
		clientService.deleteCustomer(acctID);
	}
	
	

}
